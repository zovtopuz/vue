$(document).ready(function() {
    $(".container").fadeIn(5000);
    $(".container").slideDown(5000);
    $(".container").fadeIn(5000);
});